package com.zybooks.jeremysinventoryapp.databases;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class ItemDatabase extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "users.db";
    private static final int VERSION = 1;

    public ItemDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    private static final class ItemTable {
        private static final String TABLE = "items";
        private static final String COL_ID = "_id";
        private static final String COL_NAME = "name";
        private static final String COL_ISBN = "ISBN";

        private static final String COL_DEPARTMENT = "Department";

        private static final String COL_DESCRIPTION = "Description";

        private static final String COL_PRICE = "Price";

        private static final String COL_QUANTITY = "Quantity";


    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + ItemTable.TABLE + " (" +
                ItemTable.COL_ID + " integer primary key autoincrement, " +
                ItemTable.COL_NAME + " text, " +
                ItemTable.COL_ISBN + " text, " +
                ItemTable.COL_DEPARTMENT + " text, " +
                ItemTable.COL_DESCRIPTION + " text, " +
                ItemTable.COL_PRICE + " text, " +
                ItemTable.COL_QUANTITY + " text)");



    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {
        db.execSQL("drop table if exists " + ItemTable.TABLE);
        onCreate(db);
    }

    public long addUser(String itemName,String itemISBN, String itemDepartment,
                        String itemDescription, String itemPrice, String itemQuantity) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(ItemTable.COL_NAME, itemName);
        values.put(ItemTable.COL_ISBN, itemISBN);
        values.put(ItemTable.COL_DEPARTMENT, itemDepartment);
        values.put(ItemTable.COL_DESCRIPTION, itemDescription);
        values.put(ItemTable.COL_PRICE, itemPrice);
        values.put(ItemTable.COL_QUANTITY, itemQuantity);

        long userId = db.insert(ItemTable.TABLE, null, values);
        return userId;
    }

    public String verifyUser(String userName, String userPassword) {
        SQLiteDatabase db = getReadableDatabase();

        String sql = "select * from " + ItemTable.TABLE + " where userName = ?";
        String userType = "UnRegistered";
        Cursor cursor = db.rawQuery(sql, new String[] { userName });
        if (cursor.moveToFirst()) {
            do {
                long id = cursor.getLong(0);
                String name = cursor.getString(1);
                String password = cursor.getString(2);
                String type = cursor.getString(3);
                if (name.equals(userName) && password.equals(userPassword)){
                    userType = type;
                }

            } while (cursor.moveToNext());
        }
        cursor.close();





        return userType;
    }

}
