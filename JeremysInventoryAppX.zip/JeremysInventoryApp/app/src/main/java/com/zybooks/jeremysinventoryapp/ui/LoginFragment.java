package com.zybooks.jeremysinventoryapp.ui;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.zybooks.jeremysinventoryapp.R;

public class LoginFragment extends Fragment {
    private final String GAME_STATE = "gameState";

    private GridLayout mLightGrid;
    private int mLightOnColor;
    private int mLightOffColor;





    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View parentView = inflater.inflate(R.layout.fragment_login, container, false);





        Button newGameBtn = parentView.findViewById(R.id.buttonLogin);
        newGameBtn.setOnClickListener(v -> loginUser());

        Button newRegisterButton = parentView.findViewById(R.id.buttonRegister);
        newRegisterButton.setOnClickListener(v -> registerUser());







        return parentView;
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        //outState.putString(GAME_STATE, mGame.getState());
    }

    public void setText(String text){
        TextView textView = getView().findViewById(R.id.textViewTitle);
        textView.setText(text);
    }

    private void loginUser() {
        setText("Logging in...(dummy text)");

    }
    private void registerUser() {
        setText("Registering User...(dummy text)");

    }



}








