package com.zybooks.jeremysinventoryapp.databases;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class UserDatabase extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "users.db";
    private static final int VERSION = 1;

    public UserDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    private static final class UserTable {
        private static final String TABLE = "users";
        private static final String COL_ID = "_id";
        private static final String COL_NAME = "name";
        private static final String COL_PASSWORD = "password";
        private static final String COL_TYPE = "user_type";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + UserTable.TABLE + " (" +
                UserTable.COL_ID + " integer primary key autoincrement, " +
                UserTable.COL_NAME + " text, " +
                UserTable.COL_PASSWORD + " text, " +
                UserTable.COL_TYPE + " text)");


        addUser("ad","ad", "Admin");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {
        db.execSQL("drop table if exists " + UserTable.TABLE);
        onCreate(db);
    }

    public long addUser(String userName,String userPassword, String userType) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(UserTable.COL_NAME, userName);
        values.put(UserTable.COL_PASSWORD, userPassword);
        values.put(UserTable.COL_TYPE, userType);

        long userId = db.insert(UserTable.TABLE, null, values);
        return userId;
    }

    public String verifyUser(String userName, String userPassword) {
        SQLiteDatabase db = getReadableDatabase();

        String sql = "select * from " + UserTable.TABLE + " where userName = ?";
        String userType = "UnRegistered";
        Cursor cursor = db.rawQuery(sql, new String[] { userName });
        if (cursor.moveToFirst()) {
            do {
                long id = cursor.getLong(0);
                String name = cursor.getString(1);
                String password = cursor.getString(2);
                String type = cursor.getString(3);
                if (name.equals(userName) && password.equals(userPassword)){
                    userType = type;
                }

            } while (cursor.moveToNext());
        }
        cursor.close();





        return userType;
    }

}
