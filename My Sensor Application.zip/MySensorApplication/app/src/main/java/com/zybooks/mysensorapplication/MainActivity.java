package com.zybooks.mysensorapplication;

import static androidx.constraintlayout.helper.widget.MotionEffect.TAG;

import androidx.appcompat.app.AppCompatActivity;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.RadioButton;
import android.widget.TextView;

import java.util.List;

public class MainActivity extends AppCompatActivity
        implements SensorEventListener {
    // My sensor application will use the ambient temperature sensor
    private SensorManager mSensorManager;

    private Sensor mTemperatureSensor;

    private TextView mTextCurrentTemperature;

    private RadioButton mRadioKelvin, mRadioCelsius,mRadioFahrenheit;

    private float  temperatureReading;
    private String temperatureReadingString;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mTextCurrentTemperature = findViewById(R.id.textCurrentTemperature);
        mRadioKelvin = findViewById(R.id.radioKelvin);
        mRadioCelsius = findViewById(R.id.radioCelsius);
        mRadioFahrenheit = findViewById(R.id.radioButtonFahrenheit);

        mSensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);


         mTemperatureSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_AMBIENT_TEMPERATURE);



        if (mTemperatureSensor  == null) {
            // No ambient temp sensor on this device
            //Log.d(TAG, "No ambient temperature sensor");
            mTextCurrentTemperature.setText("None");
        } else {

            mTextCurrentTemperature.setText("Temperature Sensor Present");

        }




    }

    protected void onResume() {
        super.onResume();

        mSensorManager.registerListener(this, mTemperatureSensor,
                SensorManager.SENSOR_DELAY_NORMAL);

    }

    protected void onPause() {
        super.onPause();

        mSensorManager.unregisterListener(this, mTemperatureSensor);
    }

    public void onSensorChanged(SensorEvent sensorEvent) {
      //  if (sensorEvent.sensor.getType() == Sensor.TYPE_AMBIENT_TEMPERATURE) {
        temperatureReading = sensorEvent.values[0];
        temperatureReadingString = String.valueOf(temperatureReading);
        // For some reason, the initial reading is not the actual ambient temperature, but
        // -1.0e30. Once you change the senor readings in extended controls it displays the
        // correct temperature.
        // Presumably in a real phone this would not happen, or change so quickly that it would not
        // be a factor
        if (temperatureReadingString.equals( "-1.0E30")){

            mTextCurrentTemperature.setText("Please Change Sensor Input to See Reading");
        } else {
            if (mRadioCelsius.isChecked()){
                temperatureReadingString = String.valueOf(temperatureReading) + " Celsius";
                mTextCurrentTemperature.setText(temperatureReadingString);
            }
            if (mRadioKelvin.isChecked()){
                temperatureReadingString = String.valueOf(temperatureReading + 273.125) + " Kelvin";
                mTextCurrentTemperature.setText(temperatureReadingString);
            }
            if (mRadioFahrenheit.isChecked()){
                float conversionToF = ((temperatureReading * 9) / 5)  + 32;
                temperatureReadingString = conversionToF + " Fahrenheit";
                mTextCurrentTemperature.setText(temperatureReadingString);
            }



        }




    }

    public void onAccuracyChanged(Sensor sensor, int accuracy) {}
    //
    //  This was more just done to get more practice with radio buttons
    //  But essentially it converts the temperature to other scales
    //
    public void onRadioButtonScaleClicked(View view) {

        if (temperatureReadingString.equals( "-1.0E30")){

            mTextCurrentTemperature.setText("Please Change Sensor Input to See Reading");
        } else {
            if (mRadioCelsius.isChecked()){
                temperatureReadingString = String.valueOf(temperatureReading) + " Celsius";
                mTextCurrentTemperature.setText(temperatureReadingString);
            }
            if (mRadioKelvin.isChecked()){
                temperatureReadingString = String.valueOf(temperatureReading + 273.125) + " Kelvin";
                mTextCurrentTemperature.setText(temperatureReadingString);
            }
            if (mRadioFahrenheit.isChecked()){
                float conversionToF = ((temperatureReading * 9) / 5)  + 32;
                temperatureReadingString = String.valueOf(conversionToF) + " Fahrenheit";
                mTextCurrentTemperature.setText(temperatureReadingString);

            }



        }

    }
}